import { authMiddleware } from "@clerk/nextjs";

// Toutes les routes sont protégées par défaut, sauf celles listées ici
// (accueil publique en lecture, CGU, et les webhooks/API publics).
export default authMiddleware({
  publicRoutes: ["/", "/terms", "/product/(.*)", "/api/webhooks/(.*)"],
});

export const config = {
  matcher: ["/((?!.+\\.[\\w]+$|_next).*)", "/", "/(api|trpc)(.*)"],
};
